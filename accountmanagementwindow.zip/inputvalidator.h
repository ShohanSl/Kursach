#pragma once
#include <QString>

class InputValidator {
public:
    enum class Mode {
        LettersHyphensSpaces,        // рус/англ буквы, пробелы, дефисы
        LatinAlnumHyphensUnderscore, // латиница, цифры, -, _
        NonEmpty                     // строка не пустая
    };

    static void validateOrThrow(const QString& text, Mode mode);
};
