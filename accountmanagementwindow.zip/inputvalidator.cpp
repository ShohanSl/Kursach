#include "inputValidator.h"
#include "validationexception.h"

#include <QRegularExpression>

void InputValidator::validateOrThrow(const QString& text, Mode mode) {

    switch (mode) {

    case Mode::LettersHyphensSpaces: {
        QRegularExpression re(
            "^[A-Za-zА-Яа-яЁё\\-\\s]+$",
            QRegularExpression::UseUnicodePropertiesOption
            );
        if (text.isEmpty() || !re.match(text).hasMatch()) {
            throw ValidationException(
                "Разрешены только русские/английские буквы, пробелы и дефисы."
                );
        }
        return;
    }

    case Mode::LatinAlnumHyphensUnderscore: {
        QRegularExpression re("^[A-Za-z0-9\\-_]+$");
        if (text.isEmpty() || !re.match(text).hasMatch()) {
            throw ValidationException(
                "Разрешены только латинские буквы, цифры, дефис и подчёркивание."
                );
        }
        return;
    }

    case Mode::NonEmpty: {
        if (text.trimmed().isEmpty()) {
            throw ValidationException("Поле не может быть пустым.");
        }
        return;
    }
    }
}
