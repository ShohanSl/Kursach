#include "fileexception.h"

FileException::FileException(const QString& msg)
    : AppException(msg) {}
